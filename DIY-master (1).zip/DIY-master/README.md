Daftar + Auto Claim Voucher Gofood Terbaru 18/03/2020

Jangan Lupa Berdoa Sebelum Menjalankan Scripnya
Perhatikan Langkah-Langkahnya

1.pkg update
2.pkg upgrade
3.pkg install php
4.pkg install curl
5.pkg install git
7.git clone https://github.com/mrubay/DIY
8.cd DIY
9.php malioboro.php
10.Sudah Punya User Login ? : "y"
11.Masukin User Loginnya?
12.Ketikan Nama Anda
13.Masukin nomor yang mau didaftarkan
14.Masukin Kode Otpnya Tunggu sampai Selesai
15.Set pin Pilih "y" Lalu enter
16.Masukin Otp Pin-nya
17.Done

